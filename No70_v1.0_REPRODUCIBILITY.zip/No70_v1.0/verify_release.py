#!/usr/bin/env python3
"""Check the No.70 candidate package and rerun its finite mathematical checks.

This is an integrity/finite computation driver, not a formal proof checker.
The analytical all-q/all-r proof remains a manuscript for independent scrutiny.
"""
import argparse
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def integrity():
    manifest = {}
    for line in (ROOT / 'SHA256SUMS.txt').read_text('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        rel = Path(name)
        require(not rel.is_absolute() and '..' not in rel.parts and '\\' not in name,
                'Unsafe manifest path: ' + name)
        require(name not in manifest, 'Duplicate manifest entry: ' + name)
        path = ROOT / rel
        require(path.is_file() and not path.is_symlink(), 'Missing/unsafe file: ' + name)
        require(sha(path) == digest, 'SHA256 mismatch: ' + name)
        manifest[name] = digest
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    require(actual == set(manifest) | {'SHA256SUMS.txt'},
            'Strict allowlist mismatch: ' + str(sorted(actual ^ (set(manifest) | {'SHA256SUMS.txt'}))))
    source = json.loads((ROOT / 'SOURCE_PROVENANCE.json').read_text('utf-8'))
    for item in source['unchanged_extracted_files']:
        require(sha(ROOT / item['path']) == item['sha256'],
                'Frozen-code/data provenance mismatch: ' + item['path'])
    for extension, start, stop, key in [
        ('md', b'## 1. Statement, normalization, and elementary cases',
         b'## 5. What this proof does and does not establish', 'markdown_sections_1_4'),
        ('tex', b'\\subsection{1. Statement, normalization, and elementary',
         b'\\subsection{5. What this proof does and does not', 'tex_sections_1_4')
    ]:
        raw = (ROOT / ('No70_v1.0_SOURCE.' + extension)).read_bytes()
        require(raw.count(start) == raw.count(stop) == 1, 'Ambiguous mathematical section markers')
        frozen = raw[raw.index(start):raw.index(stop)]
        require(hashlib.sha256(frozen).hexdigest() == source['mathematics'][key]['sha256'],
                'Frozen mathematical text mismatch: ' + extension)
    print('PASS SHA256 / strict allowlist / frozen extraction provenance:', len(manifest), flush=True)


def path_polynomials(max_n):
    # Integer coefficients in increasing power order; independent of SymPy.
    result = [[1], [1], [0, 1]]
    for n in range(3, max_n + 1):
        a, b = result[n-2], result[n-3]
        result.append([0] + [(a[j] if j < len(a) else 0) + (b[j] if j < len(b) else 0)
                             for j in range(max(len(a), len(b)))])
    return result


def sign_at(coefficients, point):
    # Homogenized integer Horner evaluation, returning only the exact sign.
    num, den = point.numerator, point.denominator
    value, den_power = coefficients[-1], 1
    for coefficient in reversed(coefficients[:-1]):
        den_power *= den
        value = value * num + coefficient * den_power
    return (value > 0) - (value < 0)


def bracket_roots(coefficients, encoded, label):
    degree = len(coefficients) - 1
    require(len(encoded) == degree, 'Wrong number of root brackets: ' + label)
    require(coefficients[-1] > 0 and all(c >= 0 for c in coefficients),
            'Polynomial coefficient/degree failure: ' + label)
    intervals = []
    for pair in encoded:
        require(len(pair) == 2, 'Malformed bracket: ' + label)
        lo, hi = map(Fraction, pair)
        require(lo <= hi <= 0, 'Root bracket outside nonpositive axis: ' + label)
        if intervals:
            require(intervals[-1][1] < lo, 'Overlapping/unsorted root brackets: ' + label)
        if lo == hi:
            require(sign_at(coefficients, lo) == 0, 'Incorrect exact root: ' + label)
        else:
            require(sign_at(coefficients, lo) * sign_at(coefficients, hi) == -1,
                    'Bracket has no certified sign change: ' + label)
        intervals.append((lo, hi))
    # degree distinct real roots exhaust the degree; hence every root is simple.
    return intervals


def validate_certificates():
    F = path_polynomials(200)
    seen = []
    checked_brackets = 0
    batches = [(5, 140), (141, 180), (181, 200)]
    for start, end in batches:
        name = 'INTERLACING_Q' + str(start) + '_Q' + str(end) + '.json'
        data = json.loads((ROOT / 'data' / name).read_text('utf-8'))
        require(data['from_q'] == start and data['to_q'] == end, 'Certificate batch range mismatch')
        records = data['certificates']
        require(len(records) == end-start+1, 'Missing certificate records')
        require([r['q'] for r in records] == list(range(start, end+1)), 'Certificate q coverage mismatch')
        for record in records:
            q = record['q']
            m, d, e = q // 3, (q-1) // 2 - q // 3, int(q % 2 == 0)
            raw = [[0, 0] + F[q-5], [0] + [2*c for c in F[q-2]], F[q-1]]
            require(all(all(c == 0 for c in p[:m]) for p in raw), 'Normalization divisibility failed')
            a, b, c = [p[m:] for p in raw]
            require((len(a)-1, len(b)-1, len(c)-1) == (d, d+e, d), 'Degree identity failed')
            require((record['d'], record['e']) == (d, e), 'Stored degree metadata mismatch')
            ra, rb, rc = [bracket_roots(p, record[key], 'q=' + str(q) + ' ' + key)
                          for p, key in zip((a, b, c), ('a_roots', 'b_roots', 'c_roots'))]
            less = lambda u, v: u[1] < v[0]
            shared_zero = lambda u, v: u == v == (Fraction(0), Fraction(0))
            for i in range(d):
                require(less(rc[i], ra[i]), 'c<a interlacing failed')
                after = rb[i+e]
                require(less(ra[i], after) or (i == d-1 and shared_zero(ra[i], after)),
                        'a<=b interlacing failed')
                if e:
                    require(less(rb[i], rc[i]), 'b<c interlacing failed')
                elif i+1 < d:
                    require(less(rb[i], rc[i+1]), 'b<c interlacing failed')
            common = bool(d and shared_zero(ra[-1], rb[-1]))
            require(common == record['trailing_common_zero'], 'Common-zero metadata mismatch')
            checked_brackets += len(ra) + len(rb) + len(rc)
            seen.append(q)
    require(seen == list(range(5, 201)), 'Global q coverage mismatch')
    print('PASS exact stored certificates: q=5..200, families=196, root brackets=' + str(checked_brackets), flush=True)


def without_version(data):
    return {k: v for k, v in data.items() if k not in {'sympy', 'sympy_version'}}


def rerun(temp):
    env = os.environ.copy()
    env.pop('PYTHONOPTIMIZE', None)
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    for script, options, reference, output in [
        ('verify_v09.py', ['--max-q', '45', '--max-q-sturm', '19', '--max-r-sturm', '6'],
         'RECOMPUTED_V09_EVIDENCE.json', 'v09.json'),
        ('verify_bridge_v010.py', ['--max-q', '48'], 'BRIDGE_EVIDENCE_V010.json', 'bridge.json')
    ]:
        destination = temp / output
        subprocess.run([sys.executable, '-B', str(ROOT / 'code' / script)] + options +
                       ['--output', str(destination)], check=True, cwd=temp, env=env)
        current = json.loads(destination.read_text('utf-8'))
        frozen = json.loads((ROOT / 'data' / reference).read_text('utf-8'))
        require(without_version(current) == without_version(frozen), 'Frozen finite summary mismatch: ' + script)
    print('PASS frozen finite summaries: 90 root-count cases; 227 guidepost assertions', flush=True)
    return env


def full_intervals(temp, env):
    for start, end in [(5, 140), (141, 180), (181, 200)]:
        subprocess.run([sys.executable, '-B', str(ROOT / 'code' / 'verify_interlacing_v08.py'),
                        '--start', str(start), '--end', str(end), '--output-dir', str(temp)],
                       check=True, cwd=temp, env=env)
        name = 'INTERLACING_Q' + str(start) + '_Q' + str(end) + '.json'
        current = json.loads((temp / name).read_text('utf-8'))
        frozen = json.loads((ROOT / 'data' / name).read_text('utf-8'))
        require(without_version(current) == without_version(frozen), 'Regenerated interval certificate mismatch')
    print('PASS full interval regeneration: q=5..200', flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--full-intervals', action='store_true')
    args = ap.parse_args()
    require(not sys.flags.optimize, 'Run without Python optimization; inherited programs use assertions')
    integrity()
    validate_certificates()
    with tempfile.TemporaryDirectory(prefix='no70_finite_') as directory:
        temp = Path(directory)
        env = rerun(temp)
        if args.full_intervals:
            full_intervals(temp, env)
    print('NO70 V1.0 PACKAGE / FINITE CHECK PASS; NOT FORMAL PROOF OR NOVELTY CERTIFICATION', flush=True)


if __name__ == '__main__':
    main()
